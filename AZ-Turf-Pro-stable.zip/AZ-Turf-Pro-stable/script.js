const API = "/api/analyse";

const tableBody = document.getElementById("table-body");
const btnRefresh = document.getElementById("btn-refresh");

const kpiFavorite = document.getElementById("kpi-favorite");
const kpiConfidence = document.getElementById("kpi-confidence");
const kpiOutsider = document.getElementById("kpi-outsider");

const topCombination = document.getElementById("top-combination");
const ticketsBox = document.getElementById("tickets");



async function chargerAnalyse() {

try {

const response = await fetch(API);

const data = await response.json();



// Informations course

document.getElementById("meta-course").textContent =
data.course || "-";

document.getElementById("meta-hippodrome").textContent =
data.hippodrome || "-";

document.getElementById("meta-discipline").textContent =
data.discipline || "-";

document.getElementById("meta-distance").textContent =
(data.distance_course || "-") + " m";

document.getElementById("meta-partants").textContent =
data.partants || "-";




// Chevaux

const chevaux = data.classement || data.chevaux || [];

tableBody.innerHTML = "";



chevaux.forEach((cheval,index)=>{


const tr = document.createElement("tr");


tr.innerHTML = `

<td>
<span class="num-badge">
${cheval.numero || "-"}
</span>
</td>


<td>
<strong>
${cheval.nom || "Cheval"}
</strong>
</td>


<td>
${cheval.jockey || "-"}
</td>


<td>
${cheval.entraineur || "-"}
</td>


<td>
${cheval.forme || "-"}
</td>


<td>

<div class="score-bar-container">

<span>
${cheval.indice_az || cheval.score || 0}
</span>


<div class="score-bar">

<div class="score-fill"
style="width:${Math.min(cheval.indice_az || 0,100)}%">
</div>

</div>

</div>

</td>



<td>

<span class="badge-rank ${
index === 0 ? "top1" :
index < 3 ? "top3" :
"outsider"
}">

${cheval.rang || index+1}

</span>

</td>

`;


tableBody.appendChild(tr);


});






// KPI


if(chevaux.length){


kpiFavorite.textContent =
`${chevaux[0].numero} - ${chevaux[0].nom}`;


kpiConfidence.textContent =
(chevaux[0].confiance || "88") + "%";



const outsider =
chevaux.find(c=>c.rang>=3) || chevaux[chevaux.length-1];


kpiOutsider.textContent =
`${outsider.numero} - ${outsider.nom}`;


}






// Pronostic


if(data.tickets){


topCombination.innerHTML = `

<div class="combo-pill">
<span>Q+</span>
${data.tickets.quinte.join(" - ")}
</div>


<div class="combo-pill">
<span>Q</span>
${data.tickets.quarte.join(" - ")}
</div>


<div class="combo-pill">
<span>T</span>
${data.tickets.trio.join(" - ")}
</div>

`;



ticketsBox.innerHTML = `

<p>
🥇 Couplé gagnant :
<strong>
${data.tickets.couple_gagnant.join(" - ")}
</strong>
</p>


<p>
🥈 Couplés placés :
<br>
${data.tickets.couple_place
.map(c=>c.join(" - "))
.join("<br>")}
</p>


<p>
🔒 Champ réduit :
<br>
Bases :
<strong>
${data.tickets.champ_reduit.bases.join(" - ")}
</strong>

<br>

Compléments :
<strong>
${data.tickets.champ_reduit.complements.join(" - ")}
</strong>

</p>

`;

}



}

catch(error){

console.log("Erreur API :",error);

}

}





btnRefresh.onclick = ()=>{

chargerAnalyse();

};



chargerAnalyse();
