# =====================================
# AZ TURF PRO
# API
# Analyse + Premium
# =====================================
#
# Fichier complet : api.py
# =====================================

from fastapi import APIRouter, HTTPException
from fastapi.responses import RedirectResponse, JSONResponse

from engine import lancer_analyse

from database import (
    creer_abonnement,
    activer_abonnement,
    verifier_premium,
    lister_abonnements,
    statistiques_abonnements
)

from models import (
    AbonnementRequest,
    ActivationRequest
)

from pmu_source import charger_course_pmu
from lonab_source import recuperer_journal_lonab, diagnostiquer_journal_lonab
from learning import lire_historique, mettre_a_jour_arrivee, mettre_a_jour_publications

import json
import os
from datetime import datetime, timedelta

# Nouveaux imports pour le téléchargement direct des PDF
import httpx
from bs4 import BeautifulSoup


router = APIRouter(
    prefix="/api",
    tags=["AZ Turf"]
)


# =====================================
# CHARGEMENT COURSE LOCALE
# =====================================
def charger_course_locale():
    chemin = os.path.join(os.path.dirname(__file__), "data", "courses.json")
    with open(chemin, "r", encoding="utf-8") as fichier:
        return json.load(fichier)


# =====================================
# CHARGEMENT COURSE
# PMU PRIORITAIRE + FALLBACK LOCAL
# =====================================
def charger_course():
    aujourd_hui = datetime.now()
    date_pmu = aujourd_hui.strftime("%d%m%Y")
    
    try:
        course = charger_course_pmu(date_pmu)
        if course and isinstance(course, dict) and course.get("chevaux"):
            print("Source utilisée : PMU réel")
            return course, "pmu_live"
    except Exception as erreur:
        print("PMU indisponible :", erreur)

    try:
        course = charger_course_locale()
        if course and isinstance(course, dict) and course.get("chevaux"):
            print("Source utilisée : données locales (démo)")
            course["donnees_demo"] = True
            return course, "demo"
    except Exception as erreur:
        print("Erreur chargement local :", erreur)
        
    return None, "none"


# =====================================
# ANALYSE AZ TURF
# =====================================
@router.get("/analyse")
def analyse():
    try:
        course, source = charger_course()
        if not course:
            raise HTTPException(status_code=503, detail="Aucune donnée de course disponible actuellement.")
            
        chevaux = course.get("chevaux", [])
        if not chevaux:
            raise HTTPException(status_code=503, detail="Aucun cheval trouvé dans la course.")
            
        resultat = lancer_analyse(
            chevaux,
            info_course={
                "date": course.get("date"),
                "reunion": course.get("reunion"),
                "course_numero": course.get("course_numero"),
                "course": course.get("course", ""),
                "hippodrome": course.get("hippodrome"),
                "discipline": course.get("discipline", ""),
                "distance": course.get("distance_course", ""),
                "allocation": course.get("allocation", ""),
                "heure_depart": course.get("heure_depart", ""),
                "horaires": course.get("horaires", {}),
                "non_partants": course.get("non_partants", []),
            }
        )

        if not isinstance(resultat, dict):
            raise Exception("Réponse invalide du moteur AZ")
            
        classement = resultat.get("chevaux", [])
        if not classement:
            raise Exception("Le moteur AZ n'a retourné aucun classement.")
            
        aujourd_hui = datetime.now()
        est_demo = (source == "demo")
        date_course = (course.get("date") or aujourd_hui.strftime("%Y-%m-%d"))
        reunion = (course.get("reunion") or "R1")
        course_numero = (course.get("course_numero") or "C1")
        
        reponse = {
            "message": "Analyse AZ Turf terminée" if not est_demo else "Analyse AZ Turf terminée (données de démonstration, aucune course réelle disponible actuellement)",
            "source": source,
            "donnees_demo": est_demo,
            "course": course.get("course", "Course"),
            "date": date_course,
            "reunion": reunion,
            "course_numero": course_numero,
            "heure_depart": course.get("heure_depart", ""),
            "horaires": course.get("horaires", {"depart": course.get("heure_depart", ""), "arret_des_jeux": ""}),
            "hippodrome": course.get("hippodrome", ""),
            "discipline": course.get("discipline", ""),
            "distance": course.get("distance_course", ""),
            "allocation": course.get("allocation", ""),
            "non_partants": resultat.get("non_partants", course.get("non_partants", [])),
            "plus_joues": course.get("plus_joues", []),
            "source_plus_joues": course.get("source_plus_joues", "Non disponible"),
            "partants": len(course.get("chevaux", [])),
            "chevaux": classement,
            "partants_complets": resultat.get("partants_complets", course.get("chevaux", [])),
            "classement": classement,
            "favori": (classement[0] if classement else {}),
            "tickets": resultat.get("tickets", {})
        }

        if est_demo:
            reponse["avertissement"] = "Ces données sont des données de démonstration figées et ne correspondent pas à une course réelle du jour."
            
        return reponse
        
    except HTTPException:
        raise
    except Exception as erreur:
        print("Erreur analyse AZ :", erreur)
        raise HTTPException(status_code=500, detail=f"Erreur AZ : {str(erreur)}")


# =====================================
# CREATION ABONNEMENT PREMIUM
# =====================================
@router.post("/abonnement")
def abonnement(data: AbonnementRequest):
    try:
        resultat = creer_abonnement(data.model_dump())
        return {"message": "Abonnement enregistré", "abonnement": resultat}
    except Exception as erreur:
        raise HTTPException(status_code=500, detail=str(erreur))


# =====================================
# ACTIVATION PREMIUM ADMIN
# =====================================
@router.post("/activation")
def activation_premium(activation: ActivationRequest):
    abonnement = activer_abonnement(activation.telephone, activation.reference)
    if abonnement is None:
        raise HTTPException(status_code=404, detail="Aucun abonnement trouvé")
        
    abonnement["date_fin"] = (datetime.now() + timedelta(days=int(abonnement.get("duree", 30)))).isoformat()
    return {"message": "Premium activé", "statut": "ACTIF", "date_fin": abonnement["date_fin"]}


# =====================================
# VERIFICATION PREMIUM
# =====================================
@router.get("/premium/{telephone}")
def premium(telephone: str):
    return verifier_premium(telephone)


# =====================================
# ADMIN - ABONNEMENTS
# =====================================
@router.get("/admin/abonnements")
def admin_abonnements():
    return {"abonnements": lister_abonnements()}


# =====================================
# ADMIN - STATISTIQUES
# =====================================
@router.get("/admin/statistiques")
def admin_statistiques():
    return statistiques_abonnements()


# =====================================
# JOURNAL HIPPIQUE (LONAB) - CLASSIQUE
# =====================================
@router.get("/journal")
def journal():
    try:
        aujourd_hui = datetime.now()
        resultat = recuperer_journal_lonab(aujourd_hui)
        if not resultat:
            raise HTTPException(status_code=503, detail="Journal hippique LONAB indisponible actuellement.")

        actualites_az = []
        try:
            mettre_a_jour_publications()
            historiques = lire_historique()
            for entree in reversed(historiques):
                if entree.get("publication_statut") != "PUBLIE":
                    continue
                tickets = entree.get("tickets") or {}
                course = entree.get("course") or {}
                arrivee = entree.get("arrivee") or []
                actualites_az.append({
                    "date": entree.get("date_analyse", ""),
                    "course": course,
                    "selection_az": entree.get("selection_az") or (tickets.get("gratuit") or {}).get("quinte") or [],
                    "arrivee_quinte": arrivee[:5] if isinstance(arrivee, list) else [],
                    "tickets": tickets,
                    "heure_arrivee": entree.get("heure_arrivee"),
                    "date_publication": entree.get("date_publication"),
                    "titre": "Résultat et analyse AZ Turf Pro",
                    "statut": "PUBLIE",
                })
        except Exception as erreur:
            print("Actualites AZ indisponibles :", erreur)

        resultat["actualites_az"] = actualites_az
        return resultat
    except HTTPException:
        raise
    except Exception as erreur:
        print("Erreur journal LONAB :", erreur)
        raise HTTPException(status_code=500, detail=f"Erreur journal : {str(erreur)}")


# =====================================
# DEBUG TEMPORAIRE - JSON BRUT PMU
# =====================================
@router.get("/debug-pmu")
def debug_pmu():
    from pmu_source import trouver_quinte_du_jour
    aujourd_hui = datetime.now()
    date_pmu = aujourd_hui.strftime("%d%m%Y")
    
    try:
        programme, reunion, course = trouver_quinte_du_jour(date_pmu)
        return {"reunion": reunion, "programme_brut": programme, "course_brute": course}
    except Exception as erreur:
        raise HTTPException(status_code=500, detail=f"Erreur debug PMU : {erreur}")


# =====================================
# DEBUG TEMPORAIRE - JOURNAL LONAB
# =====================================
@router.get("/debug-journal")
def debug_journal():
    aujourd_hui = datetime.now()
    try:
        diagnostic = diagnostiquer_journal_lonab(aujourd_hui)
        return diagnostic
    except Exception as erreur:
        raise HTTPException(status_code=500, detail=f"Erreur debug journal : {erreur}")


# =====================================
# HISTORIQUE (SELECTION + RESULTATS)
# =====================================
@router.get("/historique")
def historique():
    try:
        entrees = lire_historique()
        for index, entree in enumerate(entrees):
            if entree.get("arrivee"):
                continue
            info_course = entree.get("course") or {}
            date = info_course.get("date")
            reunion = info_course.get("reunion")
            course_numero = info_course.get("course_numero")

            if not (date and reunion and course_numero):
                continue

            try:
                from pmu_source import recuperer_arrivee_pmu
                arrivee = recuperer_arrivee_pmu(date, reunion, course_numero)
                if arrivee:
                    mettre_a_jour_arrivee(index, arrivee)
                    entree["arrivee"] = arrivee
            except Exception:
                pass

        try:
            mettre_a_jour_publications()
            entrees = lire_historique()
        except Exception:
            pass

        historique_normalise = []
        for entree in reversed(entrees):
            tickets = entree.get("tickets") or {}
            gratuit = tickets.get("gratuit") or {}
            selection_az = (entree.get("selection_az") or gratuit.get("quinte") or [])
            arrivee = entree.get("arrivee") or []
            entree["selection_az"] = selection_az
            entree["arrivee_quinte"] = (arrivee[:5] if isinstance(arrivee, list) else [])
            entree["publication_statut"] = (entree.get("publication_statut") or ("PUBLIE" if entree.get("arrivee") else "EN ATTENTE"))
            historique_normalise.append(entree)

        return {"historique": historique_normalise}

    except Exception as erreur:
        raise HTTPException(status_code=500, detail=f"Erreur historique : {erreur}")


# =========================================================
# =========================================================
# NOUVELLES ROUTES : TÉLÉCHARGEMENT DIRECT PDF & BRUITS
# =========================================================
# =========================================================

# Fonction de scraping
async def chercher_lien_pdf_lonab(url_page: str, mots_cles: list) -> str:
    try:
        async with httpx.AsyncClient(verify=False) as client:
            reponse = await client.get(url_page, timeout=15.0)
            reponse.raise_for_status()
            
            soup = BeautifulSoup(reponse.text, 'html.parser')
            
            for lien in soup.find_all('a', href=True):
                href = lien['href']
                texte_lien = lien.get_text().lower()
                
                if href.endswith('.pdf'):
                    if any(mot in texte_lien or mot in href.lower() for mot in mots_cles):
                        return href
                        
    except Exception as e:
        print(f"Erreur de scraping LONAB : {e}")
        
    return "https://www.lonab.bf"

# Routes de redirection
@router.get("/pdf/journal/aujourdhui")
async def get_pdf_journal_aujourdhui():
    url_lonab = "https://www.lonab.bf/journal-hippique"
    lien_direct = await chercher_lien_pdf_lonab(url_lonab, ["aujourd", "jour"])
    return RedirectResponse(url=lien_direct)

@router.get("/pdf/journal/demain")
async def get_pdf_journal_demain():
    url_lonab = "https://www.lonab.bf/journal-hippique"
    lien_direct = await chercher_lien_pdf_lonab(url_lonab, ["demain"])
    return RedirectResponse(url=lien_direct)

@router.get("/pdf/journal/special-15-aout")
async def get_pdf_journal_special():
    url_lonab = "https://www.lonab.bf/journal-hippique"
    lien_direct = await chercher_lien_pdf_lonab(url_lonab, ["15", "aout", "août"])
    return RedirectResponse(url=lien_direct)

@router.get("/pdf/arrivees/dernieres")
async def get_pdf_arrivees():
    url_lonab = "https://www.lonab.bf/resultats-et-rapports"
    lien_direct = await chercher_lien_pdf_lonab(url_lonab, ["arrivee", "rapport", "resultat"])
    return RedirectResponse(url=lien_direct)

@router.get("/pdf/programmes/mali")
async def get_pdf_programme_mali():
    return RedirectResponse(url="https://pmug.ml/programme.pdf")

@router.get("/pdf/programmes/niger")
async def get_pdf_programme_niger():
    return RedirectResponse(url="https://www.lona-niger.ne/programme.pdf")

@router.get("/bruits-ecurie")
async def get_bruits_ecurie():
    donnees = {
        "tuyau": "Repéré ce matin lors des derniers heats : le numéro 4 montre une grande souplesse. Coup de poker idéal.",
        "avis_pros": "Il redescend de catégorie aujourd'hui et affectionne particulièrement ce parcours. Place dans les 3."
    }
    return JSONResponse(content=donnees)

# =====================================
# ETAT COURSE / HORAIRES
# =====================================
@router.get("/etat-course")
def etat_course():
    """
    Fournit au frontend les informations nécessaires au chronomètre
    et au statut de la course : heure de départ, arrêt des jeux,
    date, réunion, numéro et statut temporel.
    """
    try:
        course, source = charger_course()

        if not course:
            raise HTTPException(
                status_code=503,
                detail="Aucune course disponible actuellement."
            )

        heure_depart = (
            course.get("heure_depart")
            or (course.get("horaires") or {}).get("depart")
            or ""
        )

        horaires = course.get("horaires") or {}
        arret_des_jeux = horaires.get("arret_des_jeux") or ""

        return {
            "source": source,
            "date": course.get("date", ""),
            "reunion": course.get("reunion", ""),
            "course_numero": course.get("course_numero", ""),
            "course": course.get("course", ""),
            "hippodrome": course.get("hippodrome", ""),
            "discipline": course.get("discipline", ""),
            "heure_depart": heure_depart,
            "horaires": {
                "depart": heure_depart,
                "arret_des_jeux": arret_des_jeux,
            },
            "non_partants": course.get("non_partants", []),
            "statut": "HEURE_NON_DISPONIBLE" if not heure_depart else "PROGRAMMEE",
        }

    except HTTPException:
        raise
    except Exception as erreur:
        raise HTTPException(
            status_code=500,
            detail=f"Erreur état course : {str(erreur)}"
        )


# =====================================
# ACTUALITES AZ / JOURNAL
# =====================================
@router.get("/journal/actualites")
def journal_actualites():
    """
    Route dédiée au frontend Journal.
    Retourne uniquement les publications AZ déjà disponibles.
    """
    try:
        mettre_a_jour_publications()
        entrees = lire_historique()

        actualites = []

        for entree in reversed(entrees):
            if entree.get("publication_statut") != "PUBLIE":
                continue

            tickets = entree.get("tickets") or {}
            premium = tickets.get("premium") or {}
            gratuit = tickets.get("gratuit") or {}
            course = entree.get("course") or {}
            arrivee = entree.get("arrivee") or []

            actualites.append({
                "date": entree.get("date_analyse", ""),
                "course": course,
                "favori": entree.get("favori") or {},
                "selection_premium_az": (
                    entree.get("selection_premium_az")
                    or premium.get("selection_quinte")
                    or []
                ),
                "arrivee_officielle": (
                    arrivee[:5] if isinstance(arrivee, list) else []
                ),
                "tickets": tickets,
                "selection_az": (
                    entree.get("selection_az")
                    or gratuit.get("quinte")
                    or []
                ),
                "heure_arrivee": entree.get("heure_arrivee"),
                "date_publication": entree.get("date_publication"),
                "publication_statut": "PUBLIE",
            })

        return {"actualites": actualites}

    except Exception as erreur:
        raise HTTPException(
            status_code=500,
            detail=f"Erreur actualités AZ : {str(erreur)}"
        )


# =====================================
# ETAT ADMINISTRATIF DES SOURCES
# =====================================
@router.get("/admin/etat")
def admin_etat():
    """
    Vue synthétique destinée au tableau de bord administrateur.
    Cette route ne modifie aucune donnée.
    """
    try:
        historiques = lire_historique()

        return {
            "api": "OK",
            "historique": {
                "nombre": len(historiques),
                "route": "/api/historique",
            },
            "journal": {
                "route": "/api/journal",
                "actualites": "/api/journal/actualites",
            },
            "analyse": {
                "route": "/api/analyse",
            },
            "premium": {
                "verification": "/api/premium/{telephone}",
                "abonnement": "/api/abonnement",
                "activation": "/api/activation",
            },
            "administration": {
                "abonnements": "/api/admin/abonnements",
                "statistiques": "/api/admin/statistiques",
            },
            "documents": {
                "journal_aujourdhui": "/api/pdf/journal/aujourdhui",
                "journal_demain": "/api/pdf/journal/demain",
                "arrivees": "/api/pdf/arrivees/dernieres",
            },
            "divers": {
                "etat_course": "/api/etat-course",
                "bruits_ecurie": "/api/bruits-ecurie",
            },
        }

    except Exception as erreur:
        raise HTTPException(
            status_code=500,
            detail=f"Erreur état administrateur : {str(erreur)}"
        )
