# =====================================
# AZ TURF PRO
# SOURCE LONAB - JOURNAL HIPPIQUE
# =====================================
#
# STATUT : module isole, n'est appele par aucun autre fichier du
# projet. N'affecte ni le moteur AZ (engine/scoring/ranking/quinte),
# ni pmu_source.py, ni api.py. Sert uniquement a alimenter la future
# page "journal" en contenu riche (indices, pronostics d'experts,
# actualites, lien PDF telechargeable).
#
# SOURCE : https://lonab.bf/programme-pmub - journal hippique
# officiel LONAB (Burkina Faso), publie chaque jour en PDF, libre
# d'acces, gratuit, sans connexion requise.
#
# CE QUE CE FICHIER FAIT :
# 1. Trouve le lien du PDF du jour sur la page de listing LONAB.
# 2. Telecharge le PDF et en extrait le texte brut.
# 3. Parse ce texte pour en tirer :
#    - l'entete de la course (hippodrome, libelle, distance,
#      allocation, type de pari, nombre de partants)
#    - le commentaire detaille par cheval (le vrai "indice" pour
#      l'utilisateur - texte d'expert, pas invente)
#    - le consensus de plusieurs medias reels reproduits dans le
#      journal (Turf-fr.com, Le Parisien, L'Alsace, Equidia,
#      Turfomania, L'Est Eclair...)
#    - le classement synthetique (FORME/CLASSE/PROGRES/REGULARITE)
#    - les favoris/outsiders/gros outsiders
#    - entraineurs et jockeys en forme
#    - les horaires (arret des jeux, depart)
#    - les resultats recents (actualites : arrivees des courses
#      precedentes)
#    - le lien direct du PDF (pour le bouton "programme
#      telechargeable")
#
# LIMITES ASSUMEES (pas d'invention) :
# - Le PDF n'est pas une API structuree : le format peut varier
#   legerement d'un jour a l'autre. Les extractions les plus fiables
#   (commentaires par cheval, consensus medias, favoris, horaires,
#   actualites) reposent sur des mots-cles fixes du journal LONAB et
#   sont robustes. Le tableau brut des partants (jockey/entraineur/
#   corde/poids par cheval) repose sur une reconstruction positionnelle
#   plus fragile ; si elle echoue, le reste du journal continue de
#   fonctionner (aucune exception ne remonte).
# - "Ecosysteme des ecuries" (historique croise par entraineur sur
#   plusieurs courses/jours) n'est PAS couvert par ce fichier : un
#   seul PDF ne donne qu'un instantane du jour, pas un historique.
#   Ce serait une evolution separee (necessiterait d'agreger
#   plusieurs journaux dans le temps, via database.py).
# - Certains jours, LONAB publie un TIERCE ou un QUARTE plutot qu'un
#   QUINTE+ (le PMU ne propose pas un Quinte+ tous les jours). Ce
#   module retourne le type reel tel quel, sans le forcer a "Quinte".


import re
import requests

try:
    import pdfplumber
    PDFPLUMBER_DISPONIBLE = True
except ImportError:
    PDFPLUMBER_DISPONIBLE = False


LONAB_BASE_URL = "https://lonab.bf"
LONAB_PROGRAMME_URL = f"{LONAB_BASE_URL}/programme-pmub"

TIMEOUT = 10

MOIS_FR = {
    1: "JANVIER", 2: "FEVRIER", 3: "MARS", 4: "AVRIL",
    5: "MAI", 6: "JUIN", 7: "JUILLET", 8: "AOUT",
    9: "SEPTEMBRE", 10: "OCTOBRE", 11: "NOVEMBRE", 12: "DECEMBRE",
}


# =====================================
# 1. TROUVER LE PDF DU JOUR
# =====================================

def _normaliser_accents(texte):
    """
    Retire les accents d'un texte pour permettre une comparaison
    fiable, quelle que soit la forme exacte utilisee par le site
    LONAB (ex: 'AOUT' vs 'AOÛT').
    """
    import unicodedata

    normalise = unicodedata.normalize("NFKD", texte)

    return "".join(
        caractere
        for caractere in normalise
        if not unicodedata.combining(caractere)
    )


def trouver_url_pdf_du_jour(date_obj):
    """
    Cherche, sur la page de listing LONAB, le lien du journal
    hippique correspondant a la date donnee (objet datetime.date
    ou datetime.datetime).

    Deux methodes essayees, dans l'ordre :
    1. Recherche du libelle de date dans la page HTML de listing
       (insensible aux accents et aux espaces multiples).
    2. Repli : URL directe prevmarisible, deja confirmee valide
       pour au moins une date reelle testee
       (ex: JH_PMUB_DU_10-08-2026.pdf).

    Retourne l'URL absolue du PDF, ou None si aucune des deux
    methodes n'aboutit.
    """

    libelle_date = (
        f"{date_obj.day:02d} {MOIS_FR[date_obj.month]} {date_obj.year}"
    )
    libelle_date_normalise = _normaliser_accents(libelle_date).upper()

    try:
        reponse = requests.get(
            LONAB_PROGRAMME_URL,
            timeout=TIMEOUT,
            headers={"User-Agent": "AZ-Turf-Pro/1.0"},
        )
        reponse.raise_for_status()
        html = reponse.text
    except Exception as erreur:
        print("Erreur page programme LONAB :", erreur)
        html = None

    if html:

        html_normalise = _normaliser_accents(html).upper()

        # Recherche insensible aux accents et aux espaces multiples
        # (\s+ au lieu d'un espace simple entre jour/mois/annee).
        motif_normalise = re.compile(
            r"DU\s+"
            + re.escape(f"{date_obj.day:02d}")
            + r"\s+"
            + re.escape(MOIS_FR[date_obj.month])
            + r"\s+"
            + re.escape(str(date_obj.year))
        )

        position = motif_normalise.search(html_normalise)

        if position:

            # On cherche le lien .pdf dans les 500 caracteres
            # suivants du HTML ORIGINAL (pas normalise, pour
            # recuperer une URL intacte).
            zone = html[position.start():position.start() + 800]

            lien = re.search(r'href="([^"]+\.pdf)"', zone, re.IGNORECASE)

            if lien:
                url_pdf = lien.group(1)

                if url_pdf.startswith("/"):
                    url_pdf = LONAB_BASE_URL + url_pdf

                return url_pdf

    # =================================
    # REPLI : URL DIRECTE PREVISIBLE
    # =================================
    # Format confirme valide par test direct :
    # https://lonab.bf/sites/default/files/2026-08/JH_PMUB_DU_10-08-2026.pdf

    url_directe = (
        f"{LONAB_BASE_URL}/sites/default/files/"
        f"{date_obj.year}-{date_obj.month:02d}/"
        f"JH_PMUB_DU_{date_obj.day:02d}-{date_obj.month:02d}-{date_obj.year}.pdf"
    )

    try:
        verification = requests.head(
            url_directe,
            timeout=TIMEOUT,
            headers={"User-Agent": "AZ-Turf-Pro/1.0"},
        )

        if verification.status_code == 200:
            return url_directe

    except Exception as erreur:
        print("Erreur verification URL directe LONAB :", erreur)

    return None


# =====================================
# 2. TELECHARGER ET EXTRAIRE LE TEXTE
# =====================================

def extraire_texte_pdf(url_pdf):
    """
    Telecharge le PDF et retourne son texte brut concatene, ou None
    en cas d'echec (reseau, format invalide, pdfplumber absent).
    """

    if not PDFPLUMBER_DISPONIBLE:
        print(
            "pdfplumber n'est pas installe : "
            "ajoutez-le a requirements.txt"
        )
        return None

    try:
        reponse = requests.get(
            url_pdf,
            timeout=TIMEOUT,
            headers={"User-Agent": "AZ-Turf-Pro/1.0"},
        )
        reponse.raise_for_status()
    except Exception as erreur:
        print("Erreur telechargement PDF LONAB :", erreur)
        return None

    try:
        import io

        with pdfplumber.open(io.BytesIO(reponse.content)) as pdf:
            pages = [page.extract_text() or "" for page in pdf.pages]

        return "\n".join(pages)

    except Exception as erreur:
        print("Erreur extraction texte PDF LONAB :", erreur)
        return None


# =====================================
# 3a. ENTETE DE COURSE
# =====================================

def extraire_entete(texte):
    """
    Extrait le type de pari, l'hippodrome, le libelle de la course,
    la distance, l'allocation et le nombre de concurrents.
    Champs non trouves = chaine vide, jamais invente.
    """

    resultat = {
        "type_pari": "",
        "hippodrome": "",
        "libelle_course": "",
        "distance": "",
        "allocation": "",
        "nombre_concurrents": None,
    }

    type_pari = re.search(r'"(QUINTE\+?|QUARTE|TIERCE)"', texte)
    if type_pari:
        resultat["type_pari"] = type_pari.group(1)

    hippodrome = re.search(
        r"\n([A-ZÀ-Ü'\- ]{4,})\s*-\s*(PRIX[^\n]+)", texte
    )
    if hippodrome:
        resultat["hippodrome"] = hippodrome.group(1).strip()
        resultat["libelle_course"] = hippodrome.group(2).strip()

    nb_concurrents = re.search(r"(\d+)\s+CONCURRENTS", texte)
    if nb_concurrents:
        resultat["nombre_concurrents"] = int(nb_concurrents.group(1))

    distance = re.search(r"(\d[\d\s]*)\s*METRES", texte)
    if distance:
        resultat["distance"] = distance.group(1).replace(" ", "") + "m"

    allocation = re.search(r"([\d\s]+)\s*EUROS", texte)
    if allocation:
        resultat["allocation"] = allocation.group(1).strip() + " EUROS"

    return resultat


# =====================================
# 3b. COMMENTAIRES PAR CHEVAL (LES INDICES)
# =====================================

def extraire_commentaires_chevaux(texte, nombre_concurrents):
    """
    Extrait le commentaire d'expert pour chaque cheval, au format
    reel du journal : "N - NOM : texte...".
    Retourne une liste de dicts {numero, nom, commentaire}.
    """

    if not nombre_concurrents:
        return []

    commentaires = []

    motif = re.compile(
        r"^(\d{1,2})\s*-\s*([A-ZÀ-Ü' ]{2,}?)\s*:\s*(.+?)"
        r"(?=\n\d{1,2}\s*-\s*[A-ZÀ-Ü' ]{2,}?\s*:|\Z)",
        re.DOTALL | re.MULTILINE,
    )

    for numero_str, nom, texte_commentaire in motif.findall(texte):
        numero = int(numero_str)

        if numero < 1 or numero > nombre_concurrents:
            continue

        commentaire_propre = " ".join(texte_commentaire.split())

        commentaires.append({
            "numero": numero,
            "nom": nom.strip(),
            "commentaire": commentaire_propre,
        })

    commentaires.sort(key=lambda c: c["numero"])

    return commentaires


# =====================================
# 3c. CONSENSUS DES MEDIAS REELS
# =====================================

MEDIAS_CONNUS = [
    "TURF-FR.COM", "LE PARISIEN", "L'ALSACE", "EQUIDIA",
    "TURFOMANIA", "L'EST ECLAIR", "PARIS TURF", "TIERCE MAGAZINE",
]


def extraire_consensus_medias(texte):
    """
    Extrait, pour chaque media reel identifie dans le journal, sa
    propre liste ordonnee de numeros. Ne garde que les medias
    reellement presents dans ce numero du journal (pas de liste
    fixe imposee).
    """

    resultats = {}

    for media in MEDIAS_CONNUS:
        motif = re.compile(
            re.escape(media) + r"\s+((?:\d{1,2}\s*-\s*)+\d{1,2})"
        )

        trouve = motif.search(texte)

        if trouve:
            numeros = [
                int(n.strip())
                for n in trouve.group(1).split("-")
                if n.strip().isdigit()
            ]

            if numeros:
                resultats[media] = numeros

    return resultats


# =====================================
# 3d. FAVORIS / OUTSIDERS / CLASSEMENT
# =====================================

def extraire_synthese(texte):
    """
    Extrait FAVORIS, le classement synthetique
    (FORME/CLASSE/PROGRES/REGULARITE) et les entraineurs/jockeys en
    forme, tels qu'imprimes dans le journal.
    """

    resultat = {
        "favoris": [],
        "classement": {},
        "entraineurs_en_forme": [],
        "jockeys_en_forme": [],
    }

    # Correction des plages regex pour eviter les erreurs de caracteres corrompus
    favoris = re.search(
        r"FAVORIS\s*:\s*((?:\d{1,2}\s*[-–—]\s*)+\d{1,2})", texte
    )
    if favoris:
        resultat["favoris"] = [
            int(n.strip())
            for n in re.split(r"[-–—]", favoris.group(1))
            if n.strip().isdigit()
        ]

    for critere in ("FORME", "CLASSE", "PROGRES", "REGULARITE"):
        motif = re.search(
            critere + r"\s*:\s*((?:\d{1,2}\s*[-–—]\s*)+\d{1,2})", texte
        )
        if motif:
            resultat["classement"][critere.lower()] = [
                int(n.strip())
                for n in re.split(r"[-–—]", motif.group(1))
                if n.strip().isdigit()
            ]

    entraineurs = re.search(
        r"ENTRAINEURS EN FORME\s*:\s*([^\n]+)", texte
    )
    if entraineurs:
        resultat["entraineurs_en_forme"] = [
            nom.strip()
            for nom in re.split(r"[-–—]", entraineurs.group(1))
            if nom.strip()
        ]

    jockeys = re.search(
        r"JOCKEYS EN FORME\s*:\s*([^\n]+)", texte
    )
    if jockeys:
        resultat["jockeys_en_forme"] = [
            nom.strip()
            for nom in re.split(r"[-–—]", jockeys.group(1))
            if nom.strip()
        ]

    return resultat


# =====================================
# 3e. HORAIRES
# =====================================

def extraire_horaires(texte):
    resultat = {"arret_des_jeux": "", "depart": ""}

    arret = re.search(
        r"ARR[EÉÊ]T DES JEUX EST FIX[EÉ]\s*:\s*([0-9hHmMn ]+)", texte
    )
    if arret:
        resultat["arret_des_jeux"] = arret.group(1).strip()

    depart = re.search(
        r"D[EÉ]PART DE LA COURSE\s*:\s*([0-9hHmMn ]+)", texte
    )
    if depart:
        resultat["depart"] = depart.group(1).strip()

    return resultat


# =====================================
# 3f. ACTUALITES (RESULTATS RECENTS)
# =====================================

def extraire_actualites(texte):
    """
    Extrait les arrivees des courses precedentes mentionnees dans
    le journal (sert d'actualite/rappel pour l'utilisateur).
    """

    actualites = []

    motif = re.compile(
        r'ARRIVEE DU\s+"(QUINTE\+?|QUARTE|TIERCE)"\s+DU\s+'
        r"([A-ZÉ]+\s+\d{1,2}\s+\w+\s+\d{4})\s*:\s*"
        r"((?:\d{1,2}\s*-\s*)+\d{1,2})"
    )

    for type_pari, date_texte, arrivee_texte in motif.findall(texte):
        arrivee = [
            int(n.strip())
            for n in arrivee_texte.split("-")
            if n.strip().isdigit()
        ]

        actualites.append({
            "type_pari": type_pari,
            "date": date_texte.strip(),
            "arrivee": arrivee,
        })

    return actualites


def extraire_masses_a_partager(texte):
    """
    Extrait les montants "Masse a partager" imprimes dans le
    journal (rapports financiers des dernieres courses).
    """

    montants = re.findall(
        r"Masse\s+[àa]\s+partager\s*:\s*([\d\s]+)\s*F", texte
    )

    return [m.strip() + " F" for m in montants]




# =====================================
# RESULTATS / GAINS LONAB
# =====================================

def trouver_url_resultats_du_jour(date_obj):
    """Trouve le PDF officiel des résultats/gains LONAB du jour."""
    url_page = f"{LONAB_BASE_URL}/resultats-gains-pmub"
    libelle = _normaliser_accents(
        f"{date_obj.day:02d} {MOIS_FR[date_obj.month]} {date_obj.year}"
    ).upper()
    try:
        reponse = requests.get(url_page, timeout=TIMEOUT, headers={"User-Agent": "AZ-Turf-Pro/1.0"})
        reponse.raise_for_status()
        html = reponse.text
    except Exception as erreur:
        print("Erreur page resultats LONAB :", erreur)
        return None

    html_n = _normaliser_accents(html).upper()
    # Les libellés LONAB sont du type : Télécharger les résultats PMU'B du 12 Aout 2026.
    motif = re.compile(
        r"TELECHARGER\s+LES\s+RESULTATS\s+PMU['’]B\s+DU\s+"
        + re.escape(f"{date_obj.day:02d}") + r"\s+"
        + re.escape(MOIS_FR[date_obj.month]) + r"\s+"
        + re.escape(str(date_obj.year)),
        re.IGNORECASE,
    )
    m = motif.search(html_n)
    if not m:
        return None

    zone = html[m.start():m.start()+1500]
    lien = re.search(r'href=["\']([^"\']+\.pdf(?:\?[^"\']*)?)["\']', zone, re.IGNORECASE)
    if not lien:
        return None
    url = lien.group(1)
    if url.startswith("/"):
        url = LONAB_BASE_URL + url
    elif url.startswith("./"):
        url = LONAB_BASE_URL + "/" + url[2:]
    return url


def extraire_resultats_et_rapports(texte):
    """Extrait les arrivées et les lignes de rapports présentes dans le PDF LONAB."""
    resultats = []
    rapports = []

    # Arrivées officielles sous plusieurs formulations.
    motifs_arrivee = [
        r"ARRIV[ÉE|EE]+\s*(?:DU\s+)?(?:QUINTE\+?|QUARTE|TIERCE)?[^:]*:\s*((?:\d{1,2}\s*[-–—]\s*)+\d{1,2})",
        r"ARRIV[ÉE|EE]+[^:]*\s((?:\d{1,2}\s*[-–—]\s*)+\d{1,2})",
    ]
    deja=set()
    for motif in motifs_arrivee:
        for m in re.finditer(motif, texte, re.IGNORECASE):
            nums=[int(x) for x in re.split(r"[-–—]",m.group(1)) if x.strip().isdigit()]
            if nums:
                cle=tuple(nums)
                if cle not in deja:
                    deja.add(cle)
                    resultats.append({"arrivee": nums, "texte": m.group(0).strip()})

    # Lignes contenant explicitement un rapport/gain/montant.
    for ligne in texte.splitlines():
        propre=" ".join(ligne.split())
        if re.search(r"\bRAPPORT(?:S)?\b|\bGAIN(?:S)?\b|MASSE\s+À\s+PARTAGER|MASSE\s+A\s+PARTAGER", propre, re.IGNORECASE):
            if len(propre) >= 5:
                rapports.append(propre)

    return resultats, rapports


def extraire_plus_joues_lonab(texte):
    """Extrait un classement explicitement marqué plus joué/tendance."""
    motifs = [
        r"PLUS\s+JOU[ÉE]S?\s*:?\s*((?:\d{1,2}\s*[-–—]\s*)+\d{1,2})",
        r"PLUS\s+JOUE[S]?\s*:?\s*((?:\d{1,2}\s*[-–—]\s*)+\d{1,2})",
        r"TENDANCE\s*:?\s*((?:\d{1,2}\s*[-–—]\s*)+\d{1,2})",
    ]
    for motif in motifs:
        m=re.search(motif,texte,re.IGNORECASE)
        if m:
            return [int(x) for x in re.split(r"[-–—]",m.group(1)) if x.strip().isdigit()]
    return []


# =====================================
# FONCTION PRINCIPALE
# =====================================

def recuperer_journal_lonab(date_obj):
    """
    Point d'entree principal. Retourne un dict pret pour la page
    journal, ou None si la recuperation echoue a une etape critique
    (page de listing ou PDF introuvable/illisible).

    date_obj : objet datetime.date ou datetime.datetime.
    """

    try:
        url_pdf = trouver_url_pdf_du_jour(date_obj)

        if not url_pdf:
            print("PDF LONAB du jour introuvable.")
            return None

        texte = extraire_texte_pdf(url_pdf)

        if not texte:
            print("Impossible d'extraire le texte du PDF LONAB.")
            return None

        entete = extraire_entete(texte)

        commentaires = extraire_commentaires_chevaux(
            texte, entete.get("nombre_concurrents")
        )

        consensus = extraire_consensus_medias(texte)
        synthese = extraire_synthese(texte)
        horaires = extraire_horaires(texte)
        actualites = extraire_actualites(texte)
        masses_a_partager = extraire_masses_a_partager(texte)
        plus_joues = extraire_plus_joues_lonab(texte)

        resultats = []
        rapports = []
        url_resultats = trouver_url_resultats_du_jour(date_obj)
        if url_resultats:
            texte_resultats = extraire_texte_pdf(url_resultats)
            if texte_resultats:
                resultats, rapports = extraire_resultats_et_rapports(texte_resultats)

        # Le PDF du journal peut aussi contenir des arrivées récentes.
        if not resultats:
            resultats = [{"type_pari": a["type_pari"], "date": a["date"], "arrivee": a["arrivee"]} for a in actualites]

        return {
            "source": "lonab",
            "pdf_url": url_pdf,
            "pdf_resultats_url": url_resultats,
            "entete": entete,
            "commentaires_chevaux": commentaires,
            "consensus_medias": consensus,
            "synthese": synthese,
            "horaires": horaires,
            "actualites": actualites,
            "resultats": resultats,
            "rapports": rapports,
            "masses_a_partager": masses_a_partager,
            "plus_joues": plus_joues,
            "source_plus_joues": "LONAB" if plus_joues else "non disponible dans le journal LONAB",
        }

    except Exception as erreur:
        print("Erreur recuperation journal LONAB :", erreur)
        return None


# =====================================
# DIAGNOSTIC DETAILLE (etape par etape)
# =====================================
#
# N'affecte pas recuperer_journal_lonab() ci-dessus. Sert
# uniquement a exposer, via une route de debug temporaire dans
# api.py, a quelle etape precise la recuperation echoue - sans
# necessiter un acces aux logs Render.

def diagnostiquer_journal_lonab(date_obj):

    diagnostic = {
        "libelle_date_recherchee": (
            f"{date_obj.day:02d} {MOIS_FR[date_obj.month]} "
            f"{date_obj.year}"
        ),
        "page_listing_accessible": False,
        "url_pdf_trouvee": None,
        "pdf_telecharge_et_lisible": False,
        "longueur_texte_extrait": 0,
        "erreur": None,
    }

    try:
        reponse = requests.get(
            LONAB_PROGRAMME_URL,
            timeout=TIMEOUT,
            headers={"User-Agent": "AZ-Turf-Pro/1.0"},
        )
        reponse.raise_for_status()
        diagnostic["page_listing_accessible"] = True
        diagnostic["taille_page_listing"] = len(reponse.text)

    except Exception as erreur:
        diagnostic["erreur"] = (
            f"Page de listing LONAB inaccessible : {erreur}"
        )
        return diagnostic

    url_pdf = trouver_url_pdf_du_jour(date_obj)
    diagnostic["url_pdf_trouvee"] = url_pdf

    if not url_pdf:
        diagnostic["erreur"] = (
            "Aucun lien PDF trouve sur la page de listing pour "
            "la date recherchee (le libelle de date ne correspond "
            "peut-etre pas exactement au format utilise par LONAB "
            "ce jour-la)."
        )
        return diagnostic

    diagnostic["pdfplumber_disponible"] = PDFPLUMBER_DISPONIBLE

    texte = extraire_texte_pdf(url_pdf)

    if not texte:
        diagnostic["erreur"] = (
            "PDF trouve mais impossible d'en extraire le texte "
            "(pdfplumber absent, telechargement echoue, ou PDF "
            "illisible)."
        )
        return diagnostic

    diagnostic["pdf_telecharge_et_lisible"] = True
    diagnostic["longueur_texte_extrait"] = len(texte)
    diagnostic["extrait_texte"] = texte[:500]

    return diagnostic


# =====================================
# TEST
# =====================================

if __name__ == "__main__":
    from datetime import datetime

    resultat = recuperer_journal_lonab(datetime.now())

    if resultat:
        print("Journal LONAB recupere.")
        print("Course :", resultat["entete"])
        print("Chevaux commentes :", len(resultat["commentaires_chevaux"]))
    else:
        print("Journal LONAB indisponible aujourd'hui.")
        
        
